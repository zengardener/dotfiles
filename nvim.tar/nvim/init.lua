require("core.set")

local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
  vim.fn.system({
    "git",
    "clone",
    "--filter=blob:none",
    "https://github.com/folke/lazy.nvim.git",
    "--branch=stable", -- latest stable release
    lazypath,
  })
end
vim.opt.rtp:prepend(lazypath)

require("lazy").setup("plugins")
require("core.remap")

function LineNumberColors()
    vim.api.nvim_set_hl(0, 'LineNrAbove', { fg='#b4befe', bold=true })
    vim.api.nvim_set_hl(0, 'LineNr', { fg='white', bold=true })
    vim.api.nvim_set_hl(0, 'LineNrBelow', { fg='#74C7EC', bold=true })
end

LineNumberColors()

vim.cmd [[
    au bufnewfile *.sh 0r ~/.config/nvim/skeleton/skeleton.sh
]]
