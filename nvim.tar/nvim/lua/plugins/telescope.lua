return {
  'nvim-telescope/telescope.nvim',
  lazy = false,
  tag = '0.1.6',
  -- or                            , branch = '0.1.x',
  dependencies =  {
    'nvim-lua/plenary.nvim'
  },
}
