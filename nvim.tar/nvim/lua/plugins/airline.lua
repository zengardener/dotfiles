return {
  'vim-airline/vim-airline',
  lazy = false,
  priority = 1000,
--  'vim-airline/vim-airline-themes'
}
