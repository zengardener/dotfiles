return {
  'tpope/vim-fugitive',
  lazy = true,
}
